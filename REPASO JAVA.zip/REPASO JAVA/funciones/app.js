//creando una funcion

//funtion declaration
function saludar(nombre) {
 console.log('bienvenido' + nombre)
}
saludar('juan')

//funtion expression
const cliente = function (nombrecliente) {
 console.log('mostrando datos del cliente: ' + nombrecliente)
}
cliente('Juan')
