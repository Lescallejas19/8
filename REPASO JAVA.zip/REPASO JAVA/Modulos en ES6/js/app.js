import nombreTarea from './tarea.js'

console.log(nombreTarea)
