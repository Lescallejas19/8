//objetos

//object literal
const persona = {
 nombre: 'juan',
 profesion: 'desarrollador web',
 edad: 500,
}
const persona2 = {
 nombre: 'juan',
 profesion: 'desarrollador web',
 edad: 500,
}
console.log(persona)
console.log(persona2)
