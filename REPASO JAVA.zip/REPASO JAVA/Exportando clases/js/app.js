import Tarea from './tareas.js'

const tarea1 = new Tarea('Aprender JavaScript', 'Urgente')

console.log(tarea1)

tarea1.mostrar()
