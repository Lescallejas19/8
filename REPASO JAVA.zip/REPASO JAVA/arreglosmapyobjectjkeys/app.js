const persona = {
 nombre: 'Juan',
 profesion: 'Desarrollador web',
 edad: 500,
}
console.log(Object.keys(persona))
