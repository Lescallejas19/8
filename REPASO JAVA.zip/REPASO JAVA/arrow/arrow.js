//arrow funtions

let viajando = (destino) => `viajando a la ciudad de:${destino}`

let viaje
viaje = viajando('paris')
viaje = viajando('londres')
console.log(viaje)
