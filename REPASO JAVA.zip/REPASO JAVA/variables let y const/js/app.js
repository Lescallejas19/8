// crear variables

// variables con var
// var aprendiendo= 'JavaScript'

// aprendiendo= true;

// variables con const

// const aprendiendo= 'JavaScript';
//aprendiendo=true;

//console.log(aprendiendo);

//let

let aprendiendo = 'Javascript'
aprendiendo = true
console.log(aprendiendo)
