// crear variables

var aprendiendo99 = true
aprendiendo99 = false
aprendiendo99 = 20
aprendiendo99 = 'Juan'
console.log(aprendiendo99)
